# IP-Ai Deployment Guide

This project is a React application built with Vite. To run it outside of AI Studio (e.g., locally or on GitHub), follow these steps.

## 1. Local Development

To run the app on your own computer:

1.  **Install Node.js**: Make sure you have Node.js installed.
2.  **Extract Files**: Download and extract all the project files into a folder.
3.  **Install Dependencies**:
    ```bash
    npm install
    ```
4.  **Set up Environment Variables**:
    *   Create a file named `.env` in the root directory.
    *   Add your Gemini API key:
        ```env
        GEMINI_API_KEY=your_actual_api_key_here
        ```
5.  **Run the App**:
    ```bash
    npm run dev
    ```
    The app will be available at `http://localhost:3000`.

## 2. Deploying to GitHub Pages

If you want to host the app on GitHub Pages (`https://your-username.github.io/your-repo-name/`):

> [!CAUTION]
> **API Key Exposure**: When you build a static site (like for GitHub Pages), your `GEMINI_API_KEY` will be baked into the JavaScript files. Anyone who visits your site can find your key. For a production app, you should use a backend server to hide your key.

1.  **Update Vite Config**:
    In `vite.config.ts`, you may need to set the `base` path to match your repository name.
    ```typescript
    export default defineConfig({
      base: '/your-repo-name/', // Replace with your actual repo name
      // ... rest of config
    });
    ```
2.  **Build the Project**:
    ```bash
    npm run build
    ```
3.  **Deploy**:
    Upload the contents of the `dist` folder to your GitHub repository's `gh-pages` branch, or use a GitHub Action to automate the build and deployment.

## Common Issues (White Screen)

If you see a blank white screen, check the following:

*   **Console Errors**: Open your browser's Developer Tools (F12) and check the "Console" tab for errors.
*   **Missing API Key**: Ensure you have provided a valid `GEMINI_API_KEY` in your environment.
*   **Incorrect Paths**: If deploying to a sub-path (like GitHub Pages), ensure the `base` path in `vite.config.ts` is set correctly.
*   **Build Artifacts**: Ensure you are serving the files from the `dist` folder after running `npm run build`, not just opening `index.html` directly from your file system.
