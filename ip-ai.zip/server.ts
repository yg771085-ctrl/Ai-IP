import "dotenv/config";
import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

import Replicate from "replicate";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const REPLICATE_KEYS = [
  process.env.REPLICATE_API_TOKEN,
  "r8_CNOabFgG8MoSoQtT1ugg1V9kJRHMAw50WiXBv",
  "r8_UoA6pd1MLWDVPNiybhznCX2Jy5NDqUy02DMc9",
  "r8_LLiImjBLlmO4zkcDQPczg9KFQPGX4fy0mD7gl"
].filter(Boolean) as string[];

const INFINITY_KEYS = [
  process.env.INFINITY_API_KEY,
  "infip-3c0a36fb"
].filter(Boolean) as string[];

const GITHUB_KEYS = [
  process.env.GITHUB_TOKEN,
  "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"
].filter(Boolean) as string[];

const HUGGINGFACE_KEYS = [
  process.env.HUGGINGFACE_TOKEN,
  "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"
].filter(Boolean) as string[];

let currentReplicateKeyIndex = 0;

function getReplicateClient() {
  const key = REPLICATE_KEYS[currentReplicateKeyIndex];
  currentReplicateKeyIndex = (currentReplicateKeyIndex + 1) % REPLICATE_KEYS.length;
  return new Replicate({ auth: key });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Health check for proxy
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  const rulesPath = path.join(process.cwd(), "src", "lib", "ip-rules.json");
  const keysPath = path.join(process.cwd(), "src", "lib", "custom-keys.json");
  const statsPath = path.join(process.cwd(), "src", "lib", "stats.json");

  // API Routes
  app.get("/api/stats", (req, res) => {
    try {
      if (!fs.existsSync(statsPath)) {
        fs.writeFileSync(statsPath, JSON.stringify({ count: 0 }));
      }
      const data = fs.readFileSync(statsPath, "utf-8");
      res.json(JSON.parse(data));
    } catch (error) {
      res.status(500).json({ error: "Failed to read stats" });
    }
  });

  app.post("/api/stats/increment", (req, res) => {
    try {
      if (!fs.existsSync(statsPath)) {
        fs.writeFileSync(statsPath, JSON.stringify({ count: 0 }));
      }
      const data = JSON.parse(fs.readFileSync(statsPath, "utf-8"));
      data.count = (data.count || 0) + 1;
      fs.writeFileSync(statsPath, JSON.stringify(data, null, 2));
      res.json({ success: true, count: data.count });
    } catch (error) {
      res.status(500).json({ error: "Failed to increment stats" });
    }
  });

  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, negative_prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      // CLEAN PROMPT: Remove excessive fluff that slows down some APIs
      const cleanPrompt = prompt.substring(0, 500).trim();
      console.log("Generating image for optimized prompt:", cleanPrompt);
      
      // FASTEST STRATEGY: Race multiple providers in parallel for maximum speed
      const fastGeneration = async () => {
        const controllers = new AbortController();
        const timeout = setTimeout(() => controllers.abort(), 20000); // 20s total timeout

        const providers = [
          // Hugging Face Race (Flux Schnell - High Quality, Medium Speed)
          ...HUGGINGFACE_KEYS.map(async (key) => {
            try {
              const res = await fetch("https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-schnell", {
                method: "POST",
                headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
                body: JSON.stringify({ inputs: cleanPrompt }),
                signal: controllers.signal
              });
              
              if (!res.ok) throw new Error(`HF Failed: ${res.status}`);
              
              const blob = await res.blob();
              const arrayBuffer = await blob.arrayBuffer();
              const base64 = Buffer.from(arrayBuffer).toString('base64');
              return { imageUrl: `data:${blob.type};base64,${base64}`, engine: "huggingface" };
            } catch (e: any) {
              throw e;
            }
          }),
          // Replicate Race (Flux Schnell - High Quality, Medium Speed)
          (async () => {
            try {
              const client = getReplicateClient();
              const output = await client.run("black-forest-labs/flux-schnell", {
                input: { prompt: cleanPrompt, num_outputs: 1, aspect_ratio: "1:1", output_format: "webp", output_quality: 80 }
              }, { signal: controllers.signal } as any);
              const imageUrl = Array.isArray(output) ? output[0] : output;
              const proxiedUrl = `/api/proxy-image?url=${encodeURIComponent(imageUrl)}`;
              return { imageUrl: proxiedUrl, originalUrl: imageUrl, engine: "replicate" };
            } catch (e: any) {
              throw e;
            }
          })(),
          // GitHub Race (SDXL - Fast, Good Quality)
          ...GITHUB_KEYS.map(async (key) => {
            try {
              const response = await fetch("https://models.inference.ai.azure.com/images/generations", {
                method: "POST",
                headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
                body: JSON.stringify({ prompt: cleanPrompt, model: "stability-ai/sdxl", n: 1, size: "1024x1024" }),
                signal: controllers.signal
              });
              if (!response.ok) throw new Error("GitHub Failed");
              const data = await response.json();
              const imageUrl = data.data[0].url;
              const proxiedUrl = `/api/proxy-image?url=${encodeURIComponent(imageUrl)}`;
              return { imageUrl: proxiedUrl, originalUrl: imageUrl, engine: "github-sdxl" };
            } catch (e: any) {
              throw e;
            }
          }),
          // INSTANT FALLBACK: If others take > 3.5 seconds, return an instant Pollinations URL
          (async () => {
            await new Promise(resolve => setTimeout(resolve, 3500));
            if (controllers.signal.aborted) throw new Error("Already finished");
            
            console.log("Triggering ultra-fast fallback (Pollinations)");
            const seed = Math.floor(Math.random() * 1000000);
            const enhancedPrompt = encodeURIComponent(cleanPrompt.replace(/\s+/g, '_'));
            const key = INFINITY_KEYS[0] || "";
            const pollinationsUrl = `https://image.pollinations.ai/prompt/${enhancedPrompt}?width=1024&height=1024&nologo=true&seed=${seed}${key ? `&key=${key}` : ''}`;
            return { imageUrl: pollinationsUrl, engine: "ultra-fast-fallback" };
          })()
        ];

        try {
          const result = await Promise.any(providers);
          clearTimeout(timeout);
          controllers.abort(); 
          return result;
        } catch (e) {
          clearTimeout(timeout);
          throw e;
        }
      };

      try {
        const result = await fastGeneration();
        return res.json(result);
      } catch (err) {
        console.warn("Fast generation race failed, falling back to sequential...", err);
      }

      // Fallback 1: GitHub (Higher quality but potentially slower)
      for (const key of GITHUB_KEYS) {
        try {
          console.log("Using GitHub key for generation");
          const response = await fetch("https://models.inference.ai.azure.com/images/generations", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
            body: JSON.stringify({ prompt, model: "black-forest-labs/flux-pro", n: 1, size: "1024x1024" })
          });

          if (response.ok) {
            const data = await response.json();
            const imageUrl = data.data[0].url;
            const proxiedUrl = `/api/proxy-image?url=${encodeURIComponent(imageUrl)}`;
            return res.json({ imageUrl: proxiedUrl, originalUrl: imageUrl, engine: "github" });
          }
        } catch (err) {
          console.error("GitHub key failed...");
        }
      }

      // Fallback 2: Infinity (Near-instant URL generation)
      for (const key of INFINITY_KEYS) {
        try {
          const seed = Math.floor(Math.random() * 1000000);
          const enhancedPrompt = encodeURIComponent(prompt.replace(/\s+/g, '_'));
          const pollinationsUrl = `https://image.pollinations.ai/prompt/${enhancedPrompt}?width=1024&height=1024&nologo=true&seed=${seed}&key=${key}`;
          return res.json({ imageUrl: pollinationsUrl, engine: "infinity" });
        } catch (err) {}
      }

      // Fallback 3: Standard Pollinations (No key)
      const seed = Math.floor(Math.random() * 1000000);
      const enhancedPrompt = encodeURIComponent(prompt.replace(/\s+/g, '_'));
      const pollinationsUrl = `https://image.pollinations.ai/prompt/${enhancedPrompt}?width=1024&height=1024&nologo=true&seed=${seed}`;
      return res.json({ imageUrl: pollinationsUrl, engine: "pollinations" });
    } catch (error: any) {
      console.error("General Image Generation Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate image" });
    }
  });

  app.get("/api/proxy-image", async (req, res) => {
    const imageUrl = req.query.url as string;
    if (!imageUrl) return res.status(400).send("URL is required");

    try {
      const response = await fetch(imageUrl);
      if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);
      
      const contentType = response.headers.get("content-type");
      if (contentType) res.setHeader("Content-Type", contentType);
      
      // Cache for 24 hours
      res.setHeader("Cache-Control", "public, max-age=86400");
      
      const arrayBuffer = await response.arrayBuffer();
      res.send(Buffer.from(arrayBuffer));
    } catch (error) {
      console.error("Proxy Error:", error);
      res.status(500).send("Failed to proxy image");
    }
  });

  app.get("/api/rules", (req, res) => {
    try {
      if (!fs.existsSync(rulesPath)) {
        fs.writeFileSync(rulesPath, JSON.stringify([]));
      }
      const data = fs.readFileSync(rulesPath, "utf-8");
      res.json(JSON.parse(data));
    } catch (error) {
      res.status(500).json({ error: "Failed to read rules" });
    }
  });

  app.post("/api/rules", (req, res) => {
    try {
      const rules = req.body;
      if (!Array.isArray(rules)) {
        return res.status(400).json({ error: "Invalid rules format" });
      }
      fs.writeFileSync(rulesPath, JSON.stringify(rules, null, 2));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to save rules" });
    }
  });

  app.get("/api/keys", (req, res) => {
    try {
      if (!fs.existsSync(keysPath)) {
        fs.writeFileSync(keysPath, JSON.stringify([]));
      }
      const data = fs.readFileSync(keysPath, "utf-8");
      res.json(JSON.parse(data));
    } catch (error) {
      res.status(500).json({ error: "Failed to read keys" });
    }
  });

  app.post("/api/keys", (req, res) => {
    try {
      const keys = req.body;
      if (!Array.isArray(keys)) {
        return res.status(400).json({ error: "Invalid keys format" });
      }
      fs.writeFileSync(keysPath, JSON.stringify(keys, null, 2));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to save keys" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Global error handling to prevent crashes
  process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
  });

  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  });
}

startServer();
