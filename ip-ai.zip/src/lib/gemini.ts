import { GoogleGenAI, ThinkingLevel } from "@google/genai";

// Support for multiple API keys to rotate and avoid rate limits
let API_KEYS = [
  process.env.VITE_GEMINI_API_KEY,
  process.env.GEMINI_API_KEY,
  process.env.GEMINI_API_KEY_2,
  process.env.GEMINI_API_KEY_3,
  process.env.GEMINI_API_KEY_4,
  process.env.GEMINI_API_KEY_5,
  process.env.GEMINI_API_KEY_6,
  process.env.GEMINI_API_KEY_7,
  process.env.GEMINI_API_KEY_8,
  process.env.GEMINI_API_KEY_9,
  process.env.GEMINI_API_KEY_10,
  process.env.GEMINI_API_KEY_11,
  process.env.GEMINI_API_KEY_12,
  process.env.GEMINI_API_KEY_13,
  process.env.GEMINI_API_KEY_14,
  process.env.GEMINI_API_KEY_15,
].filter(key => key && key !== "" && !key.includes("YOUR_") && !key.includes("MY_")) as string[];

// Function to update keys from server
export async function updateApiKeys() {
  try {
    const response = await fetch('/api/keys');
    if (response.ok) {
      const customKeys = await response.json();
      if (Array.isArray(customKeys)) {
        const baseKeys = [
          process.env.VITE_GEMINI_API_KEY,
          process.env.GEMINI_API_KEY,
          process.env.GEMINI_API_KEY_2,
          process.env.GEMINI_API_KEY_3,
          process.env.GEMINI_API_KEY_4,
          process.env.GEMINI_API_KEY_5,
          process.env.GEMINI_API_KEY_6,
          process.env.GEMINI_API_KEY_7,
          process.env.GEMINI_API_KEY_8,
          process.env.GEMINI_API_KEY_9,
          process.env.GEMINI_API_KEY_10,
          process.env.GEMINI_API_KEY_11,
          process.env.GEMINI_API_KEY_12,
          process.env.GEMINI_API_KEY_13,
          process.env.GEMINI_API_KEY_14,
          process.env.GEMINI_API_KEY_15,
        ].filter(key => key && key !== "" && !key.includes("YOUR_") && !key.includes("MY_")) as string[];
        
        API_KEYS = [...new Set([...baseKeys, ...customKeys])];
      }
    }
  } catch (error) {
    console.error("Failed to update API keys:", error);
  }
}

// Initial update
updateApiKeys();

const KEY_COOLDOWN = new Map<string, number>();
const COOLDOWN_TIME = 30000; // 30 seconds cooldown for 429s

// Function to get the next key with load balancing and cooldown awareness
function getApiKey(): string {
  if (API_KEYS.length === 0) return "";
  
  const now = Date.now();
  // Filter out keys that are in cooldown
  const availableKeys = API_KEYS.filter(key => {
    const cooldownUntil = KEY_COOLDOWN.get(key) || 0;
    return now > cooldownUntil;
  });

  // If all keys are in cooldown, just use the next one anyway as a fallback
  const pool = availableKeys.length > 0 ? availableKeys : API_KEYS;
  
  // Use a combination of rotation and randomization for optimal load balancing
  const randomIndex = Math.floor(Math.random() * pool.length);
  const key = pool[randomIndex];
  
  return key;
}

// Helper to create a new AI instance with a rotated key
function getAiInstance() {
  return new GoogleGenAI({ apiKey: getApiKey() });
}

const MAX_RETRIES = 6; 
const RETRY_DELAY = 500; 

// Extreme speed optimization: Fastest models first
const MODELS = [
  "gemini-2.0-flash",
  "gemini-flash-latest",
  "gemini-3-flash-preview",
  "gemini-3.1-flash-lite-preview",
  "gemini-1.5-flash",
  "gemini-1.5-flash-8b"
];

export function mapError(error: any): string {
  const errorStr = JSON.stringify(error).toLowerCase();
  const message = error?.message?.toLowerCase() || "";

  if (errorStr.includes("400") || message.includes("api key not valid") || message.includes("invalid_argument")) {
    return "🔑 **Invalid API Key**: One of your Gemini API keys is incorrect or has expired. Please check your AI Studio Secrets.";
  }
  if (errorStr.includes("404") || message.includes("not found") || message.includes("model_not_found")) {
    return "🔍 **Model Error**: The AI model is currently unavailable in your region or the model name has changed. I'm automatically switching to a backup model.";
  }
  if (errorStr.includes("503") || message.includes("high demand") || message.includes("unavailable") || message.includes("overloaded")) {
    return "⏳ **High Demand**: The AI servers are extremely busy right now. I've tried multiple different keys and models. Please wait a few seconds and try again.";
  }
  if (errorStr.includes("429") || message.includes("quota") || message.includes("rate limit")) {
    return "🛑 **Quota Exceeded**: You've reached the limit for free requests. \n\n**How to get unlimited use:**\n1. Wait 60 seconds for the rate limit to reset.\n2. Add more API keys in Secrets (GEMINI_API_KEY_2, GEMINI_API_KEY_3, etc.) to increase your pool.\n3. Enable billing in your Google AI Studio project for higher limits.";
  }
  if (message.includes("network") || message.includes("fetch") || message.includes("failed to fetch") || message.includes("aborted")) {
    return "🌐 **Network Error**: I'm having trouble connecting to the AI servers. This could be due to a poor internet connection or a temporary service outage. Please try again in a moment.";
  }

  return "⚠️ **System Error**: Something went wrong. Try refreshing the page or checking your API keys.";
}

async function withRetry<T>(fn: (ai: GoogleGenAI, model: string) => Promise<T>): Promise<T> {
  let lastError: any;
  for (let i = 0; i < MAX_RETRIES; i++) {
    const ai = getAiInstance();
    // Rotate through models if we keep failing
    const model = MODELS[i % MODELS.length];
    
    try {
      return await fn(ai, model);
    } catch (error: any) {
      lastError = error;
      const errorStr = JSON.stringify(error).toLowerCase();
      const message = error?.message?.toLowerCase() || "";
      const currentKey = (ai as any).apiKey; // Accessing internal key for cooldown tracking
      
      const is503 = errorStr.includes("503") || error?.status === 503 || message.includes("unavailable") || message.includes("overloaded");
      const is429 = errorStr.includes("429") || error?.status === 429 || message.includes("quota") || message.includes("rate limit");
      const is404 = errorStr.includes("404") || error?.status === 404 || message.includes("not found") || message.includes("model_not_found");
      const isNetwork = message.includes("fetch") || message.includes("network");

      if (is429 && currentKey) {
        KEY_COOLDOWN.set(currentKey, Date.now() + COOLDOWN_TIME);
      }

      if ((is503 || is429 || is404 || isNetwork) && i < MAX_RETRIES - 1) {
        // Switch key/model IMMEDIATELY for speed
        console.warn(`Gemini API ${is429 ? '429' : is503 ? '503' : is404 ? '404' : 'Network'} error on ${model}, rotating... (Attempt ${i + 1}/${MAX_RETRIES})`);
        
        // Add a small delay for rate limits
        if (is429) {
          await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        }
        continue;
      }
      throw error;
    }
  }
  throw lastError;
}

export function getSystemInstruction(ipRules: string[] = [], isAdmin: boolean = false, memory?: any) {
  const rulesText = ipRules.length > 0 
    ? `\n\nCURRENT CORE UPGRADES:\n${ipRules.map((r, i) => `${i + 1}. ${r}`).join('\n')}`
    : '';

  const memoryText = memory ? `
\nMEMORY & PERSONALIZATION:
- User Preferences: ${JSON.stringify(memory.preferences)}
- Past Good Answers (Patterns to follow): ${memory.goodAnswers.slice(-3).map((a: any) => `Q: ${a.question} -> A: ${a.answer}`).join(' | ')}
- Past Bad Answers (Avoid these patterns): ${memory.badAnswers.slice(-3).map((a: any) => `Q: ${a.question} -> A: ${a.answer}`).join(' | ')}
- Frequent Topics: ${memory.frequentTopics.join(', ')}
` : '';

  const adminInstructions = isAdmin ? `
@IP DIRECTIVE (CORE UPGRADES):
- If a user message starts with "@IP", it is a "Core Upgrade Directive".
- Treat the content following "@IP" as a permanent expansion of your capabilities, knowledge, or rules.
- When you receive an @IP directive, respond with: "🚀 **CORE UPGRADE INITIALIZED** 🚀" followed by a summary of how you have integrated this new skill or knowledge.
- You can also manage API keys with:
  - "@IP KEY (key)": Adds a new Gemini API key (max 5).
  - "@IP KEY LIST": Shows all custom API keys.
  - "@IP KEY DELETE (number)": Removes a custom API key.
- You must strictly follow any rules or knowledge provided via @IP in all future interactions.` : '';

  return `You are IP-AI, a smart assistant that can handle both chat and image generation.
You MUST respond ONLY in JSON format. Never include explanations outside the JSON.

CORE BEHAVIOR:
- Always give clear, helpful, and accurate responses.
- Keep answers simple unless user asks for detail.
- Adapt to user's style over time (short vs detailed, tone).
- After every text response, you MUST append the question: "Was this helpful? (Yes/No)" to your content.

SELF-IMPROVEMENT & MEMORY:
- You continuously improve based on user feedback.
- Remember useful patterns: user preferences, frequent topics, and feedback (good/bad answers).
- If a similar question is asked, try to reuse or improve past good answers.
- Do not repeat answers marked as bad.
- If unsure about an answer, say "I’m not fully sure, but here’s the best answer".${memoryText}

PERMANENT MEMORY (@IP FEATURE):
- You have a permanent memory feature enabled via @IP commands.
- Any rules, knowledge, or personality traits provided using @IP are PERMANENT and will be remembered across all future sessions.
- Treat @IP directives as core system upgrades that cannot be forgotten.

MODE SELECTION RULES:
1. If the user asks a normal question, wants to chat, needs help, or asks for information:
   - Use "type": "text"
   - Provide a helpful, friendly answer in the "content" field.
   - Remember to end with "Was this helpful? (Yes/No)"

2. If the user EXPLICITLY asks to generate, draw, make, create, or show an image:
   - Use "type": "image"
   - Provide an optimized "prompt" and "negative_prompt".

RULES:
1. Respond ONLY in JSON.
2. Image prompt rules: 
   - DISAMBIGUATION: If the user asks for "lady finger", assume they mean the OKRA VEGETABLE unless they specify otherwise.
   - SPEED OPTIMIZATION: Keep prompts under 400 characters. Focus on the subject, style, and lighting. Avoid repetitive adjectives.
   - FACE CONSISTENCY: If the user provides an image and asks for a portrait, describe the person's key features (age, ethnicity, hair, eyes) accurately but briefly to help the generator maintain consistency.
3. Image Analysis & Vision:
   - You can see and analyze images provided by the user.
   - If an image is provided, you can discuss it, edit it (by describing changes for a new generation), or answer questions about it.
   - When analyzing, be detailed and accurate.
4. Never include API keys or sensitive data.
5. If request is unclear, ask a short question in the "content" field of a "text" type response.
6. Always choose the correct mode (text vs image) based on user intent.

FINAL RULE:
Be accurate, fast, and structured.${adminInstructions}${rulesText}`;
}

export async function chatWithGemini(messages: { role: "user" | "model"; content: string; image?: { data: string; mimeType: string } }[], ipRules: string[] = [], isAdmin: boolean = false, memory?: any) {
  if (API_KEYS.length === 0) {
    throw new Error("No Gemini API keys found. Please add them to your environment variables.");
  }

  return withRetry(async (ai, model) => {
    const contents = messages
      .filter(m => (m.content && m.content.trim() !== "") || m.image)
      .map(m => {
        const parts: any[] = [];
        if (m.content) parts.push({ text: m.content });
        if (m.image) {
          parts.push({
            inlineData: {
              data: m.image.data,
              mimeType: m.image.mimeType
            }
          });
        }
        return {
          role: m.role,
          parts
        };
      });

    const response = await ai.models.generateContent({
      model: model,
      contents,
      config: {
        systemInstruction: getSystemInstruction(ipRules, isAdmin, memory),
        temperature: 0.7,
        topP: 0.8,
        topK: 40,
        maxOutputTokens: 2048,
      }
    });

    return response.text;
  });
}

export async function* streamChatWithGemini(messages: { role: "user" | "model"; content: string; image?: { data: string; mimeType: string } }[], ipRules: string[] = [], isAdmin: boolean = false, memory?: any) {
  if (API_KEYS.length === 0) {
    throw new Error("No Gemini API keys found. Please add them to your environment variables.");
  }

  const stream = await withRetry(async (ai, model) => {
    const contents = messages
      .filter(m => (m.content && m.content.trim() !== "") || m.image)
      .map(m => {
        const parts: any[] = [];
        if (m.content) parts.push({ text: m.content });
        if (m.image) {
          parts.push({
            inlineData: {
              data: m.image.data,
              mimeType: m.image.mimeType
            }
          });
        }
        return {
          role: m.role,
          parts
        };
      });

    return await ai.models.generateContentStream({
      model: model,
      contents,
      config: {
        systemInstruction: getSystemInstruction(ipRules, isAdmin, memory),
        temperature: 0.7,
        topP: 0.8,
        topK: 40,
        maxOutputTokens: 2048,
      }
    });
  });

  try {
    for await (const chunk of stream) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error("Gemini API Streaming Error:", error);
    throw error;
  }
}
