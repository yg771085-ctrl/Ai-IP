import React, { useState, useRef, useEffect, useCallback, memo } from 'react';
import { Send, Bot, User, Sparkles, Trash2, Loader2, Plus, MessageSquare, Settings, Menu, X, PanelLeftClose, PanelLeftOpen, Info, AlertCircle, Copy, Check, Download, Image as ImageIcon, Share2, ExternalLink, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkBreaks from 'remark-breaks';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { streamChatWithGemini, mapError } from '@/lib/gemini';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  type?: 'text' | 'image';
  imageUrl?: string;
  isGeneratingImage?: boolean;
  image?: { data: string; mimeType: string };
  feedback?: 'good' | 'bad';
}

interface Memory {
  goodAnswers: { question: string; answer: string }[];
  badAnswers: { question: string; answer: string }[];
  preferences: {
    length: 'short' | 'detailed';
    tone: string;
  };
  frequentTopics: string[];
}

interface Chat {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
}

export default function ChatInterface() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAdminAreaOpen, setIsAdminAreaOpen] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [showAdminCommands, setShowAdminCommands] = useState(true);
  const [adminPassword, setAdminPassword] = useState('');
  const [adminInput, setAdminInput] = useState('');
  const [adminMessages, setAdminMessages] = useState<Message[]>([]);
  const [adminError, setAdminError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const adminScrollRef = useRef<HTMLDivElement>(null);
  const [currentTone, setCurrentTone] = useState<'Friendly' | 'Funny' | 'Teacher' | 'Professional' | 'Gamer'>(() => {
    try {
      const saved = localStorage.getItem('ip-ai-memory');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.preferences.tone || 'Friendly';
      }
    } catch (e) {}
    return 'Friendly';
  });

  useEffect(() => {
    setMemory(prev => ({
      ...prev,
      preferences: { ...prev.preferences, tone: currentTone }
    }));
  }, [currentTone]);
  const [autoScroll, setAutoScroll] = useState(true);
  const [selectedImage, setSelectedImage] = useState<{ data: string; mimeType: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isAppReady, setIsAppReady] = useState(false);
  const [memory, setMemory] = useState<Memory>(() => {
    try {
      const saved = localStorage.getItem('ip-ai-memory');
      return saved ? JSON.parse(saved) : {
        goodAnswers: [],
        badAnswers: [],
        preferences: { length: 'short', tone: 'Friendly' },
        frequentTopics: []
      };
    } catch (e) {
      return {
        goodAnswers: [],
        badAnswers: [],
        preferences: { length: 'short', tone: 'Friendly' },
        frequentTopics: []
      };
    }
  });

  useEffect(() => {
    localStorage.setItem('ip-ai-memory', JSON.stringify(memory));
  }, [memory]);

  // Load chats from localStorage with safety
  useEffect(() => {
    const initApp = async () => {
      try {
        const savedChats = localStorage.getItem('ip-ai-chats');
        if (savedChats) {
          const parsed = JSON.parse(savedChats);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setChats(parsed);
            setActiveChatId(parsed[0].id);
          }
        }
      } catch (e) {
        console.error("Failed to parse saved chats", e);
        // If corrupted, clear it to prevent hang
        localStorage.removeItem('ip-ai-chats');
      } finally {
        setIsAppReady(true);
      }
    };
    
    initApp();
  }, []);

  // Save chats to localStorage
  useEffect(() => {
    if (chats.length > 0) {
      localStorage.setItem('ip-ai-chats', JSON.stringify(chats));
    }
  }, [chats]);

  const activeChat = chats.find(c => c.id === activeChatId) || null;
  const messages = activeChat?.messages || [];

  // Detect tone from messages
  useEffect(() => {
    const lastUserMessage = [...messages].reverse().find(m => m.role === 'user');
    if (lastUserMessage) {
      const content = lastUserMessage.content.toLowerCase();
      if (content.includes('funny') || content.includes('joke')) setCurrentTone('Funny');
      else if (content.includes('teach') || content.includes('explain')) setCurrentTone('Teacher');
      else if (content.includes('professional') || content.includes('work')) setCurrentTone('Professional');
      else if (content.includes('gamer') || content.includes('game')) setCurrentTone('Gamer');
      else setCurrentTone('Friendly');
    }
  }, [messages]);

  // Auto-scroll to bottom
  const [ipRules, setIpRules] = useState<string[]>([]);
  const [customKeys, setCustomKeys] = useState<string[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [rulesRes, keysRes] = await Promise.all([
          fetch('/api/rules'),
          fetch('/api/keys')
        ]);
        
        if (rulesRes.ok) {
          const rulesData = await rulesRes.json();
          setIpRules(rulesData);
        }
        
        if (keysRes.ok) {
          const keysData = await keysRes.json();
          setCustomKeys(keysData);
        }
      } catch (err) {
        console.error('Failed to fetch data:', err);
      }
    };
    fetchData();
  }, []);

  const saveRules = async (newRules: string[]) => {
    try {
      await fetch('/api/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRules),
      });
    } catch (err) {
      console.error('Failed to save rules:', err);
    }
  };

  const saveKeys = async (newKeys: string[]) => {
    try {
      await fetch('/api/keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newKeys),
      });
      // Refresh keys in Gemini service
      const { updateApiKeys } = await import('@/lib/gemini');
      await updateApiKeys();
    } catch (err) {
      console.error('Failed to save keys:', err);
    }
  };

  const incrementAiCount = async () => {
    try {
      await fetch('/api/stats/increment', { method: 'POST' });
    } catch (err) {
      console.error('Failed to increment AI count:', err);
    }
  };

  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-slot="scroll-area-viewport"]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages, isLoading, autoScroll]);

  useEffect(() => {
    if (isAdminAreaOpen && adminScrollRef.current) {
      const scrollContainer = adminScrollRef.current.querySelector('[data-slot="scroll-area-viewport"]');
      if (scrollContainer) {
        setTimeout(() => {
          scrollContainer.scrollTop = scrollContainer.scrollHeight;
        }, 100);
      }
    }
  }, [adminMessages, isLoading, isAdminAreaOpen]);

  const createNewChat = () => {
    const newChat: Chat = {
      id: Date.now().toString(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date().toISOString(),
    };
    setChats(prev => [newChat, ...prev]);
    setActiveChatId(newChat.id);
    setError(null);
    if (window.innerWidth < 768) setIsSidebarOpen(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("Image size must be less than 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      const data = base64.split(',')[1];
      setSelectedImage({ data, mimeType: file.type });
    };
    reader.readAsDataURL(file);
  };

  const handleSend = async (isAdmin: boolean = false) => {
    let currentInput = isAdmin ? adminInput : input;
    let trimmedInput = currentInput.trim();
    if ((!trimmedInput && !selectedImage) || isLoading) return;

    setError(null);
    let currentChatId = activeChatId;
    let currentChats = [...chats];

    if (!isAdmin && !currentChatId) {
      const newChat: Chat = {
        id: Date.now().toString(),
        title: currentInput.trim() 
          ? (currentInput.trim().substring(0, 30) + (currentInput.length > 30 ? '...' : ''))
          : 'Image Analysis',
        messages: [],
        createdAt: new Date().toISOString(),
      };
      currentChats = [newChat, ...currentChats];
      currentChatId = newChat.id;
      setChats(currentChats);
      setActiveChatId(currentChatId);
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: currentInput.trim(),
      timestamp: new Date().toISOString(),
      image: selectedImage || undefined,
    };

    // Clear selected image after adding to message
    const currentSelectedImage = selectedImage;
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';

    // Detect feedback
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === 'model' && lastMessage.content.includes("Was this helpful?")) {
      const lowerInput = trimmedInput.toLowerCase();
      if (lowerInput === 'yes' || lowerInput === 'no') {
        const feedback = lowerInput === 'yes' ? 'good' : 'bad';
        
        setMemory(prev => {
          const newMemory = { ...prev };
          const interaction = { 
            question: messages[messages.length - 2]?.content || "", 
            answer: lastMessage.content 
          };
          
          if (feedback === 'good') {
            newMemory.goodAnswers.push(interaction);
          } else {
            newMemory.badAnswers.push(interaction);
          }
          return newMemory;
        });

        // If 'no', we trigger an immediate improvement
        if (lowerInput === 'no') {
          currentInput = 'Please provide a better version of your previous response, avoiding the mistakes made.';
          trimmedInput = currentInput.trim();
          setInput('');
        } else {
          setInput(''); // Clear input if it was just 'yes'
          return; // Don't send 'yes' to the AI as a new prompt
        }
      }
    }

    // Update frequent topics
    if (!isAdmin && trimmedInput.length > 5) {
      setMemory(prev => {
        const words = trimmedInput.toLowerCase().split(' ').filter(w => w.length > 4);
        const newTopics = [...new Set([...prev.frequentTopics, ...words])].slice(-20);
        return { ...prev, frequentTopics: newTopics };
      });
    }

    // Adjust preferences based on length
    if (!isAdmin) {
      setMemory(prev => ({
        ...prev,
        preferences: {
          ...prev.preferences,
          length: trimmedInput.length > 100 ? 'detailed' : 'short'
        }
      }));
    }

    // Handle @IP Commands - ONLY in Admin Area
    if (trimmedInput.toUpperCase().startsWith('@IP')) {
      if (!isAdmin) {
        setError("The @IP feature is only available in the Admin Area. Please use Settings > Admin Area.");
        setInput('');
        return;
      } else {
        if (trimmedInput.toUpperCase().startsWith('@IP RULES')) {
          const rulesList = ipRules.length > 0 
            ? ipRules.map((r, i) => `**${i + 1}.** ${r}`).join('\n\n')
            : "No active core upgrades.";
          
          const botMessage: Message = {
            id: (Date.now() + 1).toString(),
            role: 'model',
            content: `📋 **CURRENT CORE RULES:**\n\n${rulesList}`,
            timestamp: new Date().toISOString(),
          };
          
          setAdminMessages(prev => [...prev, userMessage, botMessage]);
          setAdminInput('');
          return;
        }

        if (trimmedInput.toUpperCase().startsWith('@IP DELETE')) {
          const num = parseInt(trimmedInput.toUpperCase().replace('@IP DELETE', '').trim());
          if (!isNaN(num) && num > 0 && num <= ipRules.length) {
            const deletedRule = ipRules[num - 1];
            const newRules = ipRules.filter((_, i) => i !== num - 1);
            setIpRules(newRules);
            saveRules(newRules);
            
            const botMessage: Message = {
              id: (Date.now() + 1).toString(),
              role: 'model',
              content: `🗑️ **CORE UPGRADE REMOVED**\n\nSuccessfully deleted rule #${num}: "${deletedRule}"`,
              timestamp: new Date().toISOString(),
            };
            
            setAdminMessages(prev => [...prev, userMessage, botMessage]);
          } else {
            setAdminError("Invalid rule number. Use @IP RULES to see the list.");
          }
          setAdminInput('');
          return;
        }

        if (trimmedInput.toUpperCase().startsWith('@IP KEY')) {
          const key = trimmedInput.substring(7).trim();
          if (key && !key.toUpperCase().startsWith('LIST') && !key.toUpperCase().startsWith('DELETE')) {
            if (customKeys.length >= 5) {
              setAdminError("Maximum 5 custom API keys allowed. Use @IP KEY LIST to see them.");
            } else {
              const newKeys = [...customKeys, key];
              setCustomKeys(newKeys);
              saveKeys(newKeys);
              
              const botMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'model',
                content: `🔑 **API KEY ADDED**\n\nSuccessfully added a new Gemini API key to the rotation. Total custom keys: ${newKeys.length}/5`,
                timestamp: new Date().toISOString(),
              };
              setAdminMessages(prev => [...prev, userMessage, botMessage]);
            }
          } else if (trimmedInput.toUpperCase().startsWith('@IP KEY LIST')) {
            const keysList = customKeys.length > 0 
              ? customKeys.map((k, i) => `**${i + 1}.** \`${k.substring(0, 8)}...${k.substring(k.length - 4)}\``).join('\n')
              : "No custom API keys added.";
            
            const botMessage: Message = {
              id: (Date.now() + 1).toString(),
              role: 'model',
              content: `🔑 **CUSTOM API KEYS:**\n\n${keysList}\n\n*Use @IP KEY DELETE (number) to remove a key.*`,
              timestamp: new Date().toISOString(),
            };
            setAdminMessages(prev => [...prev, userMessage, botMessage]);
          } else if (trimmedInput.toUpperCase().startsWith('@IP KEY DELETE')) {
            const num = parseInt(trimmedInput.toUpperCase().replace('@IP KEY DELETE', '').trim());
            if (!isNaN(num) && num > 0 && num <= customKeys.length) {
              const newKeys = customKeys.filter((_, i) => i !== num - 1);
              setCustomKeys(newKeys);
              saveKeys(newKeys);
              
              const botMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'model',
                content: `🗑️ **API KEY REMOVED**\n\nSuccessfully removed custom API key #${num}.`,
                timestamp: new Date().toISOString(),
              };
              setAdminMessages(prev => [...prev, userMessage, botMessage]);
            } else {
              setAdminError("Invalid key number. Use @IP KEY LIST to see the list.");
            }
          } else {
            setAdminError("Please provide an API key. Example: @IP KEY AIza...");
          }
          setAdminInput('');
          return;
        }

        if (trimmedInput.toUpperCase().startsWith('@IP COUNT')) {
          try {
            const res = await fetch('/api/stats');
            const data = await res.json();
            const botMessage: Message = {
              id: (Date.now() + 1).toString(),
              role: 'model',
              content: `📊 **TOTAL AI RESPONSES:**\n\nYour AI has given **${data.count || 0}** answers so far.`,
              timestamp: new Date().toISOString(),
            };
            setAdminMessages(prev => [...prev, userMessage, botMessage]);
          } catch (err) {
            setAdminError("Failed to fetch statistics.");
          }
          setAdminInput('');
          return;
        }

        // Normal @IP rule addition
        const newRule = trimmedInput.substring(3).trim();
        if (newRule) {
          const newRules = [...ipRules, newRule];
          setIpRules(newRules);
          saveRules(newRules);
        }
      }
    }

    if (isAdmin) {
      setAdminMessages(prev => [...prev, userMessage]);
      setAdminInput('');
    } else {
      const updatedChats = currentChats.map(c => {
        if (c.id === currentChatId) {
          const newTitle = c.messages.length === 0 
            ? currentInput.trim().substring(0, 30) + (currentInput.length > 30 ? '...' : '')
            : c.title;
          return { ...c, title: newTitle, messages: [...c.messages, userMessage] };
        }
        return c;
      });
      setChats(updatedChats);
      setInput('');
    }

    setIsLoading(true);

    const botMessageId = (Date.now() + 1).toString();
    const botMessage: Message = {
      id: botMessageId,
      role: 'model',
      content: '',
      timestamp: new Date().toISOString(),
    };

    if (isAdmin) {
      setAdminMessages(prev => [...prev, botMessage]);
    } else {
      setChats(prev => prev.map(c => 
        c.id === currentChatId ? { ...c, messages: [...c.messages, botMessage] } : c
      ));
    }

    try {
      let chatHistory;
      if (isAdmin) {
        chatHistory = [...adminMessages, userMessage].map(m => ({
          role: m.role,
          content: m.content,
          image: m.image,
        }));
      } else {
        const targetChat = currentChats.find(c => c.id === currentChatId);
        if (!targetChat) throw new Error("Chat not found");
        chatHistory = [...targetChat.messages, userMessage].map(m => ({
          role: m.role,
          content: m.content,
          image: m.image,
        }));
      }

      let fullResponse = '';
      const stream = streamChatWithGemini(chatHistory, ipRules, isAdmin, memory);

      for await (const chunk of stream) {
        fullResponse += chunk;
        
        // SPEED OPTIMIZATION: Try to extract content from JSON stream in real-time
        let displayContent = fullResponse;
        try {
          // If it looks like JSON, try to extract the "content" field for better UX during streaming
          if (fullResponse.trim().startsWith('{')) {
            // Use a more robust regex for partial JSON content extraction
            const contentMatch = fullResponse.match(/"content"\s*:\s*"((?:[^"\\]|\\.)*)"/);
            if (contentMatch && contentMatch[1]) {
              // Unescape basic characters for display
              displayContent = contentMatch[1]
                .replace(/\\n/g, '\n')
                .replace(/\\"/g, '"')
                .replace(/\\\\/g, '\\')
                .replace(/\\t/g, '\t');
            } else if (fullResponse.includes('"type"') && fullResponse.includes('"image"')) {
              displayContent = "🎨 **Fast Generation Mode Active**\n\nPreparing to generate your image using the fastest available engine...";
            }
          }
        } catch (e) {
          // Fallback to raw response if regex fails
        }

        if (isAdmin) {
          setAdminMessages(prev => {
            const newMsgs = [...prev];
            const idx = newMsgs.findIndex(m => m.id === botMessageId);
            if (idx !== -1) {
              newMsgs[idx] = { ...newMsgs[idx], content: displayContent };
            }
            return newMsgs;
          });
        } else {
          setChats(prev => {
            const chatIndex = prev.findIndex(c => c.id === currentChatId);
            if (chatIndex === -1) return prev;
            
            const newChats = [...prev];
            const chat = { ...newChats[chatIndex] };
            const messages = [...chat.messages];
            const msgIndex = messages.findIndex(m => m.id === botMessageId);
            
            if (msgIndex !== -1) {
              messages[msgIndex] = { ...messages[msgIndex], content: displayContent };
              chat.messages = messages;
              newChats[chatIndex] = chat;
              return newChats;
            }
            return prev;
          });
        }
      }

      // After stream finishes, try to parse JSON and handle image generation
      let incremented = false;
      try {
        // Clean the response from potential markdown blocks
        const cleanJson = fullResponse.replace(/```json\n?|\n?```/g, '').trim();
        const parsed = JSON.parse(cleanJson);
        
        if (parsed.type === 'image') {
          // Set generating state
          if (isAdmin) {
            setAdminMessages(prev => prev.map(m => m.id === botMessageId ? { ...m, isGeneratingImage: true, content: `🎨 Generating image: "${parsed.prompt}"...` } : m));
          } else {
            setChats(prev => prev.map(c => c.id === currentChatId ? { 
              ...c, 
              messages: c.messages.map(m => m.id === botMessageId ? { ...m, isGeneratingImage: true, content: `🎨 Generating image: "${parsed.prompt}"...` } : m) 
            } : c));
          }

          // Call image generation API
          const imgRes = await fetch('/api/generate-image', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              prompt: parsed.prompt,
              negative_prompt: parsed.negative_prompt
            }),
          });

          if (!imgRes.ok) throw new Error("Failed to generate image");
          const { imageUrl } = await imgRes.json();

          // Increment count for image generation
          incrementAiCount();
          incremented = true;

          // Update with image
          const finalContent = `![${parsed.prompt}](${imageUrl})`;
          if (isAdmin) {
            setAdminMessages(prev => prev.map(m => m.id === botMessageId ? { ...m, isGeneratingImage: false, content: finalContent, imageUrl } : m));
          } else {
            setChats(prev => prev.map(c => c.id === currentChatId ? { 
              ...c, 
              messages: c.messages.map(m => m.id === botMessageId ? { ...m, isGeneratingImage: false, content: finalContent, imageUrl } : m) 
            } : c));
          }
        } else if (parsed.type === 'text') {
          // Increment count for text response
          incrementAiCount();
          incremented = true;

          // Update with just the text content
          if (isAdmin) {
            setAdminMessages(prev => prev.map(m => m.id === botMessageId ? { ...m, content: parsed.content } : m));
          } else {
            setChats(prev => prev.map(c => c.id === currentChatId ? { 
              ...c, 
              messages: c.messages.map(m => m.id === botMessageId ? { ...m, content: parsed.content } : m) 
            } : c));
          }
        }
      } catch (e) {
        // If not valid JSON, keep the raw response (fallback)
        console.warn("Response was not valid JSON or image generation failed:", e);
      }

      // Final fallback increment if not already done and we have a response
      if (!incremented && fullResponse.trim()) {
        incrementAiCount();
      }
    } catch (err: any) {
      console.error("Chat Error:", err);
      const errorMessage = mapError(err);
      if (isAdmin) {
        setAdminError(errorMessage);
        setAdminMessages(prev => prev.map(m => m.id === botMessageId ? { ...m, content: `Error: ${errorMessage}` } : m));
      } else {
        setError(errorMessage);
        setChats(prev => prev.map(c => 
          c.id === currentChatId 
            ? { ...c, messages: c.messages.map(m => m.id === botMessageId ? { ...m, content: `I'm sorry, I encountered an error:\n\n${errorMessage}` } : m) } 
            : c
        ));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const deleteChat = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = chats.filter(c => c.id !== id);
    setChats(updated);
    if (activeChatId === id) {
      setActiveChatId(updated.length > 0 ? updated[0].id : null);
    }
    if (updated.length === 0) {
      localStorage.removeItem('ip-ai-chats');
    }
  };

  const clearAllChats = () => {
    setChats([]);
    setActiveChatId(null);
    localStorage.removeItem('ip-ai-chats');
    setIsSettingsOpen(false);
  };

  const copyToClipboard = useCallback(async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  }, []);

  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleDownload = useCallback(async (url: string, filename: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename || 'ip-ai-generated-image.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      window.open(url, '_blank');
    }
  }, []);

  const handleShare = useCallback(async (url: string, title: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'IP-Ai Generated Image',
          text: title || 'Check out this image generated by IP-Ai!',
          url: url
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      copyToClipboard(url, 'share-link');
    }
  }, [copyToClipboard]);

  const handleAdminAuth = () => {
    if (adminPassword === 'plmokn@09') {
      setIsAdminAuthenticated(true);
      setAdminError(null);
    } else {
      setAdminError('Incorrect password');
    }
  };

  if (!isAppReady) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-background gap-4">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
        <div className="text-center space-y-2">
          <p className="text-sm font-medium animate-pulse">Initializing IP-Ai...</p>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-[10px] opacity-50 hover:opacity-100"
            onClick={() => window.location.reload()}
          >
            Stuck? Refresh Page
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: isSidebarOpen ? 260 : 0, opacity: isSidebarOpen ? 1 : 0 }}
        className={cn(
          "bg-[#171717] text-white flex flex-col h-full overflow-hidden shrink-0 z-40 transition-all duration-300 ease-in-out",
          !isSidebarOpen && "pointer-events-none"
        )}
      >
        <div className="p-3 flex flex-col h-full w-[260px]">
          <Button 
            onClick={createNewChat}
            variant="ghost" 
            className="w-full justify-start gap-2 mb-2 hover:bg-white/10 text-white border border-white/20 h-10 px-3"
          >
            <Plus className="w-4 h-4" />
            <span className="text-sm font-medium">New Chat</span>
          </Button>

          <ScrollArea className="flex-1 -mx-3 px-3">
            <div className="space-y-1 py-2">
              {chats.map((chat) => (
                <div
                  key={chat.id}
                  onClick={() => {
                    setActiveChatId(chat.id);
                    if (window.innerWidth < 768) setIsSidebarOpen(false);
                  }}
                  className={cn(
                    "group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors relative",
                    activeChatId === chat.id ? "bg-white/10" : "hover:bg-white/5"
                  )}
                >
                  <MessageSquare className="w-4 h-4 shrink-0 opacity-60" />
                  <span className="text-sm truncate pr-6">{chat.title}</span>
                  <button 
                    onClick={(e) => deleteChat(chat.id, e)}
                    className="absolute right-2 opacity-0 group-hover:opacity-100 hover:text-red-400 transition-opacity p-1"
                    title="Delete chat"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="mt-auto pt-4 border-t border-white/10 space-y-1">
            <Button 
              variant="ghost" 
              className="w-full justify-start gap-3 hover:bg-white/10 text-white h-10 px-3 rounded-xl"
              onClick={() => setIsSettingsOpen(true)}
            >
              <Settings className="w-4 h-4" />
              <span className="text-sm">Settings</span>
            </Button>
            <div className="flex items-center gap-3 px-3 py-3 hover:bg-white/10 rounded-xl cursor-pointer transition-colors">
              <Avatar className="w-6 h-6 border border-white/20">
                <AvatarFallback className="bg-primary text-[10px]">YG</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium truncate">yg771085@gmail.com</span>
            </div>
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative min-w-0 h-full">
        {/* Mobile Header / Toggle */}
        <header className="h-14 border-b flex items-center px-4 shrink-0 bg-background/80 backdrop-blur-md sticky top-0 z-30">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="mr-2"
          >
            {isSidebarOpen ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeftOpen className="w-5 h-5" />}
          </Button>
          
          <div className="flex-1 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight">IP-Ai</span>
              <Badge variant="secondary" className="text-[10px] h-4 px-1.5 font-bold uppercase tracking-tighter bg-primary/5 text-primary border-primary/10">
                {currentTone}
              </Badge>
            </div>
            
            <div className="flex items-center gap-2">
              <div className={cn(
                "flex items-center gap-1.5 px-2 py-1 rounded-full border text-[10px] font-bold uppercase tracking-wider transition-colors",
                isLoading 
                  ? "bg-amber-500/10 text-amber-600 border-amber-500/20" 
                  : "bg-emerald-500/10 text-emerald-600 border-emerald-500/20"
              )}>
                <span className={cn(
                  "w-1.5 h-1.5 rounded-full",
                  isLoading ? "bg-amber-500 animate-pulse" : "bg-emerald-500"
                )} />
                {isLoading ? "Thinking..." : "Ready"}
              </div>
            </div>
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 min-h-0 relative flex flex-col">
          <ScrollArea ref={scrollRef} className="h-full w-full">
            <div className="max-w-3xl mx-auto w-full px-4 pt-8 pb-32">
              {error && (
                <div className="mb-6 p-4 bg-destructive/10 border border-destructive/20 rounded-2xl flex items-center gap-3 text-destructive text-sm animate-in fade-in slide-in-from-top-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <p>{error}</p>
                </div>
              )}

              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center text-center space-y-6 py-20">
                  <div className="w-16 h-16 bg-primary/5 rounded-full flex items-center justify-center">
                    <Sparkles className="w-8 h-8 text-primary" />
                  </div>
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tight">How can I help you today?</h2>
                    <p className="text-muted-foreground">IP-Ai is ready to assist with your tasks, questions, and creative projects.</p>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl mt-8">
                    {[
                      { icon: <MessageSquare className="w-4 h-4" />, title: "YouTube Script", desc: "Viral hook for a tech review" },
                      { icon: <Bot className="w-4 h-4" />, title: "Debug Code", desc: "Fix a React useEffect loop" },
                      { icon: <Sparkles className="w-4 h-4" />, title: "Generate Image", desc: "Cyberpunk city in the rain" },
                      { icon: <User className="w-4 h-4" />, title: "Daily Schedule", desc: "Optimize my 9-5 productivity" }
                    ].map((item, i) => (
                      <button 
                        key={i}
                        onClick={() => setInput(item.title)}
                        className="flex flex-col items-start p-4 rounded-2xl border border-muted hover:bg-muted/50 transition-all text-left group"
                      >
                        <div className="p-2 rounded-lg bg-primary/5 text-primary mb-3 group-hover:bg-primary/10 transition-colors">
                          {item.icon}
                        </div>
                        <h3 className="font-semibold text-sm">{item.title}</h3>
                        <p className="text-xs text-muted-foreground">{item.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-8">
                  <AnimatePresence initial={false}>
                    <div className="flex justify-center mb-6">
                      <div className="bg-blue-500/10 text-blue-400 text-[10px] font-bold px-3 py-1 rounded-full border border-blue-500/20 flex items-center gap-1.5 animate-pulse shadow-[0_0_15px_rgba(59,130,246,0.1)]">
                        <Zap className="w-3 h-3 fill-current" />
                        ULTRA-FAST MODE ACTIVE
                      </div>
                    </div>
                    {messages.map((message) => (
                      <MessageItem 
                        key={message.id}
                        message={message}
                        isLoading={isLoading}
                        copiedId={copiedId}
                        copyToClipboard={copyToClipboard}
                        handleDownload={handleDownload}
                        handleShare={handleShare}
                      />
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Floating Input Area */}
          <div className="absolute bottom-0 left-0 right-0 p-4 md:p-8 bg-gradient-to-t from-background via-background to-transparent pointer-events-none">
            <div className="max-w-3xl mx-auto w-full pointer-events-auto">
              {selectedImage && (
                <div className="mb-2 p-2 bg-muted/50 rounded-xl border border-muted flex items-center gap-3 animate-in slide-in-from-bottom-2">
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden border">
                    <img 
                      src={`data:${selectedImage.mimeType};base64,${selectedImage.data}`} 
                      alt="Selected" 
                      className="w-full h-full object-cover"
                    />
                    <button 
                      onClick={() => setSelectedImage(null)}
                      className="absolute top-0 right-0 bg-black/50 text-white p-0.5 rounded-bl-lg hover:bg-red-500 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Image selected</p>
                    <p className="text-[10px] truncate opacity-60">Ready for analysis or editing</p>
                  </div>
                </div>
              )}
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="relative group"
              >
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleImageUpload} 
                    accept="image/*" 
                    className="hidden" 
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute left-2 bottom-2 h-10 w-10 rounded-xl hover:bg-primary/5 text-muted-foreground hover:text-primary transition-all"
                    disabled={isLoading}
                  >
                    <ImageIcon className="w-4 h-4" />
                  </Button>
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                    placeholder="Message IP-Ai... (Cmd+Enter to send)"
                    rows={1}
                    className="w-full bg-background border border-muted-foreground/20 rounded-2xl py-4 pl-12 pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/30 transition-all resize-none shadow-lg"
                    disabled={isLoading}
                    style={{ 
                      minHeight: '56px', 
                      maxHeight: '200px',
                      height: input.split('\n').length > 1 ? 'auto' : '56px'
                    }}
                  />
                <Button 
                  type="submit" 
                  disabled={isLoading || !input.trim()}
                  size="icon"
                  className="absolute right-2 bottom-2 h-10 w-10 rounded-xl shadow-md transition-all active:scale-95"
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </form>
              <p className="text-[10px] text-center text-muted-foreground mt-3 uppercase tracking-widest font-bold opacity-40">
                IP-Ai can make mistakes. Check important info.
              </p>
            </div>
          </div>
        </div>
      </main>
      {/* Settings Dialog */}
      <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
        <DialogContent className="sm:max-w-[425px] rounded-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold tracking-tight">Settings</DialogTitle>
            <DialogDescription>
              Customize your IP-Ai experience and manage your data.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-6 py-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-semibold">Auto-scroll</Label>
                <p className="text-xs text-muted-foreground">Automatically scroll to new messages</p>
              </div>
              <Switch checked={autoScroll} onCheckedChange={setAutoScroll} />
            </div>
            
            <Separator />
            
            <div className="space-y-3">
              <Label className="text-base font-semibold">Data Management</Label>
              <div className="flex flex-col gap-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2 rounded-xl"
                  onClick={() => setIsAdminAreaOpen(true)}
                >
                  <Bot className="w-4 h-4" />
                  Open Admin Area
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2 rounded-xl"
                  onClick={() => {
                    window.location.reload();
                  }}
                >
                  <ExternalLink className="w-4 h-4" />
                  Refresh Page
                </Button>
                <Button 
                  variant="destructive" 
                  className="w-full justify-start gap-2 rounded-xl"
                  onClick={clearAllChats}
                >
                  <Trash2 className="w-4 h-4" />
                  Clear All Chats
                </Button>
                <p className="text-[10px] text-muted-foreground">Refresh Page reloads the application. Use if stuck.</p>
              </div>
            </div>

            <Separator />

            <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-2xl border border-muted">
              <Info className="w-4 h-4 text-primary shrink-0" />
              <p className="text-[10px] leading-relaxed">
                IP-Ai is an advanced assistant. Your chats are stored locally on this device.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsSettingsOpen(false)} className="rounded-xl w-full sm:w-auto">Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Admin Area Dialog */}
      <Dialog open={isAdminAreaOpen} onOpenChange={(open) => {
        setIsAdminAreaOpen(open);
        if (!open) {
          setIsAdminAuthenticated(false);
          setAdminPassword('');
          setAdminError(null);
        }
      }}>
        <DialogContent className={cn(
          "rounded-3xl transition-all duration-300 p-0 overflow-hidden",
          isAdminAuthenticated ? "sm:max-w-[1000px] w-[95vw] h-[90vh]" : "sm:max-w-[400px] p-6"
        )}>
          {!isAdminAuthenticated ? (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold tracking-tight">Admin Authentication</DialogTitle>
                <DialogDescription>
                  Enter the password to access the @IP Core Upgrade area.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <input
                    id="password"
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAdminAuth()}
                    className="w-full bg-background border border-muted-foreground/20 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    autoFocus
                  />
                  {adminError && <p className="text-xs text-destructive">{adminError}</p>}
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleAdminAuth} className="rounded-xl w-full">Login</Button>
              </DialogFooter>
            </>
          ) : (
            <div className="flex flex-col h-full overflow-hidden">
              <div className="p-6 pb-0 shrink-0">
                <DialogHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <DialogTitle className="text-2xl font-bold tracking-tight flex items-center gap-2">
                        <Bot className="w-6 h-6 text-primary" />
                        Admin Core Area
                      </DialogTitle>
                      <DialogDescription>
                        Manage @IP Core Upgrades and system rules.
                      </DialogDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="h-8 rounded-lg text-xs gap-2"
                        onClick={() => setShowAdminCommands(!showAdminCommands)}
                      >
                        <Info className="w-3.5 h-3.5" />
                        {showAdminCommands ? 'Hide Commands' : 'Show Commands'}
                      </Button>
                      <Badge className="bg-primary/10 text-primary border-primary/20">Authenticated</Badge>
                    </div>
                  </div>
                </DialogHeader>
              </div>
              
              <div className="flex-1 min-h-0 flex flex-col p-6 pt-4 gap-4 overflow-hidden">
                <AnimatePresence>
                  {showAdminCommands && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden shrink-0"
                    >
                      <div className="bg-muted/30 rounded-2xl border border-muted p-4 space-y-3">
                        <h4 className="text-sm font-bold flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Info className="w-4 h-4 text-primary" />
                            Available Commands
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-6 text-[10px] text-muted-foreground hover:text-destructive"
                            onClick={() => setAdminMessages([])}
                          >
                            Clear Admin Chat
                          </Button>
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[11px]">
                          <div className="bg-background/50 p-2 rounded-lg border border-muted">
                            <code className="text-primary font-bold">@IP [rule]</code>
                            <p className="text-muted-foreground mt-1">Add a new permanent core rule.</p>
                          </div>
                          <div className="bg-background/50 p-2 rounded-lg border border-muted">
                            <code className="text-primary font-bold">@IP RULES</code>
                            <p className="text-muted-foreground mt-1">List all active core upgrades.</p>
                          </div>
                          <div className="bg-background/50 p-2 rounded-lg border border-muted">
                            <code className="text-primary font-bold">@IP DELETE [num]</code>
                            <p className="text-muted-foreground mt-1">Remove a specific rule by number.</p>
                          </div>
                          <div className="bg-background/50 p-2 rounded-lg border border-muted">
                            <code className="text-primary font-bold">@IP KEY (key)</code>
                            <p className="text-muted-foreground mt-1">Add custom API key (max 5)</p>
                          </div>
                          <div className="bg-background/50 p-2 rounded-lg border border-muted">
                            <code className="text-primary font-bold">@IP KEY LIST</code>
                            <p className="text-muted-foreground mt-1">List custom keys</p>
                          </div>
                          <div className="bg-background/50 p-2 rounded-lg border border-muted">
                            <code className="text-primary font-bold">@IP KEY DELETE [num]</code>
                            <p className="text-muted-foreground mt-1">Remove custom key</p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex-1 min-h-0 overflow-hidden border border-muted rounded-2xl bg-background/50 flex flex-col">
                  <ScrollArea ref={adminScrollRef} className="h-full">
                    <div className="p-4 space-y-4">
                      {adminMessages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-10 text-center opacity-40">
                          <Bot className="w-12 h-12 mb-2" />
                          <p className="text-sm">Admin session active. Enter @IP commands below.</p>
                        </div>
                      ) : (
                        adminMessages.map((msg) => (
                          <div key={msg.id} className={cn(
                            "flex gap-3",
                            msg.role === 'user' ? "flex-row-reverse" : "flex-row"
                          )}>
                            <div className={cn(
                              "w-6 h-6 rounded-md flex items-center justify-center shrink-0 text-[10px]",
                              msg.role === 'user' ? "bg-primary text-primary-foreground" : "bg-muted border"
                            )}>
                              {msg.role === 'user' ? 'U' : 'A'}
                            </div>
                            <div className={cn(
                              "text-xs p-3 rounded-xl max-w-[80%]",
                              msg.role === 'user' ? "bg-primary/10 border border-primary/20" : "bg-muted/50 border border-muted"
                            )}>
                              <ReactMarkdown remarkPlugins={[remarkGfm, remarkBreaks]}>{msg.content}</ReactMarkdown>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </div>
              
              <div className="shrink-0 p-6 pt-0">
                <form 
                  onSubmit={(e) => { e.preventDefault(); handleSend(true); }}
                  className="relative"
                >
                  <textarea
                    value={adminInput}
                    onChange={(e) => {
                      setAdminInput(e.target.value);
                      if (adminError) setAdminError(null);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                        e.preventDefault();
                        handleSend(true);
                      }
                    }}
                    placeholder="Enter @IP command... (Cmd+Enter to send)"
                    rows={1}
                    className="w-full bg-background border border-muted-foreground/20 rounded-xl py-3 pl-4 pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none"
                    disabled={isLoading}
                    style={{ 
                      minHeight: '46px', 
                      maxHeight: '150px',
                      height: adminInput.split('\n').length > 1 ? 'auto' : '46px'
                    }}
                  />
                  <Button 
                    type="submit" 
                    disabled={isLoading || !adminInput.trim()}
                    size="icon"
                    className="absolute right-1.5 bottom-1.5 h-8 w-8 rounded-lg"
                  >
                    {isLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                  </Button>
                </form>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

const MessageItem = memo(({ 
  message, 
  isLoading, 
  copiedId, 
  copyToClipboard, 
  handleDownload, 
  handleShare 
}: { 
  message: Message, 
  isLoading: boolean, 
  copiedId: string | null, 
  copyToClipboard: (text: string, id: string) => void, 
  handleDownload: (url: string, filename: string) => void, 
  handleShare: (url: string, title: string) => void 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex gap-4 md:gap-6 group",
        message.role === 'user' ? "flex-row-reverse" : "flex-row"
      )}
    >
      <div className={cn(
        "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 shadow-sm border",
        message.role === 'user' ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
      )}>
        {message.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>
      
      <div className={cn(
        "flex flex-col gap-2 min-w-0 flex-1",
        message.role === 'user' ? "items-end" : "items-start"
      )}>
        <div className={cn(
          "text-sm leading-relaxed max-w-full relative group/msg",
          message.role === 'user' 
            ? "bg-primary/5 px-4 py-3 rounded-2xl rounded-tr-none border border-primary/10" 
            : "w-full"
        )}>
          {message.image && (
            <div className="mb-3 rounded-xl overflow-hidden border shadow-sm max-w-sm">
              <img 
                src={`data:${message.image.mimeType};base64,${message.image.data}`} 
                alt="Uploaded" 
                className="w-full h-auto"
              />
            </div>
          )}
          <div className="markdown-content prose prose-sm dark:prose-invert max-w-none">
            {message.isGeneratingImage ? (
              <div className="flex flex-col items-center justify-center p-8 bg-muted/20 rounded-2xl border border-dashed border-muted-foreground/30 animate-pulse">
                <Loader2 className="w-8 h-8 animate-spin text-primary mb-3" />
                <p className="text-xs font-medium text-muted-foreground">{message.content}</p>
              </div>
            ) : message.content ? (
              <ReactMarkdown 
                remarkPlugins={[remarkGfm, remarkBreaks]}
                allowedElements={['div', 'span', 'img', 'code', 'pre', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'a', 'strong', 'em', 'del']}
                unwrapDisallowed={true}
                components={{
                  p({ children }) {
                    return <div className="mb-4 last:mb-0">{children}</div>;
                  },
                  div({ children }) {
                    return <div>{children}</div>;
                  },
                  code({ node, inline, className, children, ...props }: any) {
                    const match = /language-(\w+)/.exec(className || '');
                    const codeString = String(children).replace(/\n$/, '');
                    return !inline ? (
                      <div className="relative group/code my-4">
                        <div className="flex items-center justify-between px-4 py-2 bg-muted/50 rounded-t-lg border-x border-t border-muted text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                          <span>{match ? match[1] : 'code'}</span>
                          <button
                            onClick={() => copyToClipboard(codeString, `code-${message.id}-${node.position?.start.offset}`)}
                            className="flex items-center gap-1 hover:text-foreground transition-colors"
                          >
                            {copiedId === `code-${message.id}-${node.position?.start.offset}` ? (
                              <Check className="w-3 h-3" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                            {copiedId === `code-${message.id}-${node.position?.start.offset}` ? 'Copied' : 'Copy'}
                          </button>
                        </div>
                        <pre className={cn("p-4 rounded-b-lg border border-muted bg-muted/30 overflow-x-auto", className)} {...props}>
                          <code className="block">{children}</code>
                        </pre>
                      </div>
                    ) : (
                      <code className={cn("bg-muted px-1.5 py-0.5 rounded text-xs font-mono", className)} {...props}>
                        {children}
                      </code>
                    );
                  },
                  img({ node, src, alt, ...props }: any) {
                    return <MarkdownImage src={src || ''} alt={alt || ''} onDownload={handleDownload} onShare={handleShare} />;
                  }
                }}
              >
                {message.content}
              </ReactMarkdown>
            ) : (
              isLoading && message.role === 'model' && (
                <div className="flex gap-1 items-center py-2">
                  <span className="w-1.5 h-1.5 bg-primary/40 rounded-full animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1.5 h-1.5 bg-primary/40 rounded-full animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1.5 h-1.5 bg-primary/40 rounded-full animate-bounce" />
                </div>
              )
            )}
          </div>
          
          {message.content && (
            <div className={cn(
              "flex items-center gap-2 mt-2 opacity-0 group-hover/msg:opacity-100 transition-opacity",
              message.role === 'user' ? "justify-end" : "justify-start"
            )}>
              <button
                onClick={() => copyToClipboard(message.content, message.id)}
                className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                title="Copy message"
              >
                {copiedId === message.id ? (
                  <Check className="w-3.5 h-3.5" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
});

const MarkdownImage = memo(({ src, alt, onDownload, onShare }: { src: string, alt: string, onDownload: (url: string, filename: string) => void, onShare: (url: string, title: string) => void }) => {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    if (retryCount > 0 && retryCount <= 5) {
      const timer = setTimeout(() => {
        setError(false);
        setLoading(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [retryCount]);

  // Ensure URL is encoded and use direct endpoint if possible
  let safeSrc = src;
  
  try {
    if (safeSrc) {
      // 1. Normalize the URL
      if (safeSrc.includes('pollinations.ai/p/')) {
        safeSrc = safeSrc.replace('pollinations.ai/p/', 'image.pollinations.ai/prompt/');
      }
      
      const url = new URL(safeSrc);
      
      // 2. If it's a pollinations URL, make sure the prompt part is clean
      if (url.hostname.includes('pollinations.ai')) {
        const pathParts = url.pathname.split('/');
        let promptPart = pathParts[pathParts.length - 1];
        
        // Clean and re-encode the prompt
        // We decode first to handle cases where it might be partially encoded
        promptPart = decodeURIComponent(promptPart)
          .replace(/\s+/g, '_')
          .replace(/[^a-zA-Z0-9_.-]/g, ''); // Remove anything that might break the URL
        
        pathParts[pathParts.length - 1] = promptPart;
        url.pathname = pathParts.join('/');
        
        // 3. Handle seed and retry
        const baseSeed = url.searchParams.get('seed') || '42';
        // If we are retrying, we change the seed to bypass cache and try a different generation
        const finalSeed = retryCount > 0 ? `${baseSeed}${retryCount}` : baseSeed;
        url.searchParams.set('seed', finalSeed);
        
        // 4. Ensure other params
        if (!url.searchParams.has('width')) url.searchParams.set('width', '1024');
        if (!url.searchParams.has('height')) url.searchParams.set('height', '1024');
        if (!url.searchParams.has('nologo')) url.searchParams.set('nologo', 'true');
        
        safeSrc = url.toString();
      }
    }
  } catch (e) {
    safeSrc = safeSrc?.replace(/\s/g, '%20');
  }

  return (
    <div className="relative group/img my-6 max-w-2xl">
      <div className={cn(
        "overflow-hidden rounded-2xl border border-muted shadow-xl bg-muted/20 min-h-[200px] flex items-center justify-center relative",
        loading && "animate-pulse"
      )}>
        {loading && !error && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/10 backdrop-blur-sm z-10">
            <Loader2 className="w-8 h-8 animate-spin text-primary/40" />
          </div>
        )}
        
        {error ? (
          <div className="flex flex-col items-center gap-3 p-8 text-muted-foreground">
            <ImageIcon className="w-12 h-12 opacity-20" />
            <div className="text-xs">Failed to load image. The prompt might be too complex or the service is busy.</div>
            <div className="flex gap-2 mt-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => { 
                  setError(false); 
                  setLoading(true); 
                  setRetryCount(prev => prev + 1);
                }}
                className="rounded-xl"
              >
                Retry
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => window.open(safeSrc, '_blank')}
                className="rounded-xl"
              >
                Open in new tab
              </Button>
            </div>
          </div>
        ) : (
          <img 
            key={safeSrc}
            src={safeSrc} 
            alt={alt} 
            className={cn(
              "w-full h-auto object-cover transition-all duration-700",
              loading ? "opacity-0 scale-95" : "opacity-100 scale-100",
              "group-hover/img:scale-[1.02]"
            )}
            onLoad={() => setLoading(false)}
            onError={() => { setError(true); setLoading(false); }}
            referrerPolicy="no-referrer"
          />
        )}
      </div>
      
      {!error && !loading && (
        <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover/img:opacity-100 transition-opacity z-20">
          <Button
            size="icon"
            variant="secondary"
            className="h-8 w-8 rounded-lg shadow-lg backdrop-blur-md bg-white/10 border-white/20 text-white hover:bg-white/20"
            onClick={() => onDownload(safeSrc, `ip-ai-${Date.now()}.png`)}
            title="Download image"
          >
            <Download className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="h-8 w-8 rounded-lg shadow-lg backdrop-blur-md bg-white/10 border-white/20 text-white hover:bg-white/20"
            onClick={() => onShare(safeSrc, alt)}
            title="Share image"
          >
            <Share2 className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="h-8 w-8 rounded-lg shadow-lg backdrop-blur-md bg-white/10 border-white/20 text-white hover:bg-white/20"
            onClick={() => window.open(safeSrc, '_blank')}
            title="Open in new tab"
          >
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      )}
      
      {alt && alt !== 'image' && (
        <div className="mt-2 text-[10px] text-muted-foreground italic px-2">
          {alt}
        </div>
      )}
    </div>
  );
});
